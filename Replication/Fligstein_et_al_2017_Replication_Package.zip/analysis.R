library(RColorBrewer)
source("base.R")

# Load lda results
load("FOMClda.RData")
K<- 15
lda0 <- lda15
X <- analyze.lda(lda0)

topic.labels <- c("Bank Liquidity", "General", "Employment", "Weakness", "Financial Markets",
                  "Models", "Objectives", "Housing", "Inflation", "Portfolio",
                  "Productivity", "Energy", "Housing Bubble", "Policy Response", "Minutes")

# Get topic getwords
get.topic.word.list(lda0,30,correct.stems=FALSE)

# Plot topics over time
for (k in 1:K)
  plot(time,X$topic.proportions[,k],type='l',xlab='Date',ylab='Proportion',main=topic.labels[k])

