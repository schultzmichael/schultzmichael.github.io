library(tm)
library(topicmodels)
library(reshape2)
source('setdirs.R')

#######################
# Functions
#######################

# Fixes to word preprocessing, stemming failures, nonascii characters and proper nouns
# Deletions
del.voc <- c("ken","jim","kohn","krieger","brayton","chao","chris","christin","clark","dan","dick",
             "diego","eric","frank","greg","hoeni","hoenig","joe","linda","michael","michell","marvin",
             "phillip","tetlow","bernard","bernank","alan","greenspan","josh","nathan","vince")
# Combinations
comb.voc <- list(c("cdo","cdos"),c("clo","clos"),c("cfo","cfos"),c("congress","congression"),c("cycl","cyclic"),
              c("day","day="),c("didn","didn=t"),c("don","don=t"),c("iraq","iraqi"),c("lbo","lbos"))
# Replacements
swap.voc <- list(c("communiquã©","communique"),c("dã©jã ","deja"),c("dalla","dallas"),c("naã¯v","naiv"))


# Incorporate fixes into the document term matrix (dtm)
revise.dtm <- function(dtm,del.voc,comb.voc){
  dtm <- dtm[,!(colnames(as.matrix(dtm)) %in% del.voc)]
  for(comb in comb.voc){
    #print(comb)
    new <- comb[1]
    old <- comb[-1]
    #print(dim(dtm[,colnames(as.matrix(dtm)) %in% comb]))
    dtm[,which(colnames(as.matrix(dtm))==new)] <- rowSums(as.matrix(dtm)[,colnames(as.matrix(dtm)) %in% comb])
    dtm <- dtm[,!(colnames(as.matrix(dtm)) %in% old)]
  }
  dtm
}
# Rename words
rename.voc <- function(docvoc, swap.voc){
  voc <- docvoc$voc
  for(swap in swap.voc)
    voc[voc==swap[1]] <- swap[2]
  list(voc=voc,doc=docvoc$doc)
}
# Convert document term matrix into word list and document to word mapping
dtm.to.docvoc <- function(dtm,min.count=0){
  keep <- colSums(as.matrix(dtm))>min.count
  voc <- colnames(as.matrix(dtm)[,keep])
  doc <- apply(as.matrix(dtm)[,keep], 1, function(docterms){
    k <- as.integer(which(docterms>0))
    names(k) <- NULL
    count <- as.integer(docterms[k])
    names(count) <- NULL
    adjust.for.stupidity(rbind(k,count))
  })
  list(voc=voc,doc=doc)
}
# Correct for a strange error in the package
adjust.for.stupidity <- function(doc){
  k <- doc[1,]
  count <- doc[2,]
  newk <- as.integer(unlist(sapply(1:length(k),function(j) rep(k[j],count[j]))))
  newcount <- as.integer(rep(1,length(newk)))
  rbind(newk,newcount)
}

sort.by <- function(x,k)
  x[sort(x[,k],index.return=TRUE)$ix,]
load.stem.leaf.table <- function(){
  x <-read.csv(paste0(data.dir,"translation.csv"),header=FALSE,stringsAsFactors=FALSE,strip.white=TRUE)
  x <- sort.by(x,k=1)
  y <- x[,2]
  names(y) <- x[,1]
  y
}
compress.date <- function(year,month=1,day=1)
  year+(month-1)/12 + (day-1)/365
pretty.compress.date <- function(year=NULL,month=NULL,day=NULL){
  r <- ""
  if(!is.null(month))
    r <- paste0(r,switch(month, "January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"))
  if(!is.null(day))
    r <- paste(r,round(day,0))
  if(!is.null(year)){
    if(nchar(r)>0)
      r <- paste0(r,", ")
    r <- paste0(r,round(year,0))
  }
  r
}
     
parse.doc.name <- function(doc){
  year <- as.integer(substr(doc,1,4))
  month <- as.integer(substr(doc,5,6))
  date <- as.integer(substr(doc,7,8))
  c(year,month,date,compress.date(year,month,date))
}
analyze.lda <- function(lda0){
  K <- max(sapply(lda0$assignments,max))+1
  
  word.prob.given.topic <- t(apply(lda0$topics,1,function(x) x/sum(x)))
  topic.proportions <- t(lda0$document_sums) / colSums(lda0$document_sums)
  topic.prob <- rowSums(lda0$document_sums) / sum(lda0$document_sums)
  word.topic.prob <- apply(word.prob.given.topic,2, function(wpgt) wpgt* topic.prob )
  word.prob <- colSums(word.topic.prob)
  topic.prob.given.word <- t(apply(word.topic.prob,1, function(wtp) wtp/word.prob))
  x <- topic.prob.given.word * word.prob.given.topic

  list(K=K,
       word.prob=word.prob, 
       topic.prob=topic.prob, 
       word.topic.prob=word.topic.prob,
       word.prob.given.topic=word.prob.given.topic,
       topic.prob.given.word=topic.prob.given.word,
       topic.proportions=topic.proportions,
       x=x)
}

get.topic.keywords <- function(lda0,use.x=TRUE,correct.stems=TRUE){
  X <- analyze.lda(lda0)
  
  K <- X$K
  include <- X$word.prob > 1e-5
  
  if(use.x)
    words <- lapply(1:K,function(i) X$x[i,include])
  else
    words <- lapply(1:K,function(i) X$topic.prob.given.word[i,include])
  words <- lapply(words, function(w) names(w[rev(sort(w,index.return=T)$ix)]))
  
  if(correct.stems){
    stem.leaf.translation <- load.stem.leaf.table()
    for(i in 1:K){
      x <- stem.leaf.translation[words[[i]]]
      x[is.na(x)] <- words[[i]][is.na(x)]
      words[[i]] <- x
    }
  }
  words
}
get.keyword.scores <- function(lda0,use.topic.given.word=TRUE,use.x=FALSE,correct.stems=TRUE,...){
  X <- analyze.lda(lda0)
  
  K <- X$K
  include <- X$word.prob > 1e-5
  
  if(use.topic.given.word)
    scores <- lapply(1:K,function(i) cbind(X$topic.prob.given.word[i,include],X$word.prob.given.topic[i,include],log(X$word.prob[include])))
  else
    scores <- lapply(1:K,function(i) cbind(X$word.prob.given.topic[i,include],X$topic.prob.given.word[i,include],log(X$word.prob[include])))
  if(use.x)
    scores <- lapply(1:K,function(i) cbind(X$x[i,include],X$word.prob.given.topic[i,include],log(X$word.prob[include])))
  scores <- lapply(scores, function(w) w[rev(sort(as.numeric(w[,1]),index.return=T)$ix),])
  
  if(correct.stems){
    stem.leaf.translation <- load.stem.leaf.table()
    for(i in 1:K){
      x <- stem.leaf.translation[rownames(scores[[i]])]
      x[is.na(x)] <- rownames(scores[[i]])[is.na(x)]
      rownames(scores[[i]]) <- x
    }
  }
  
  scores
}
get.topic.word.list <- function(lda0,M,collapse=NULL,...){
  words <- get.topic.keywords(lda0,...)
  sapply(words, function(w) paste(w[1:M],collapse=collapse))
}


################
# Base Script
################

# Load corpus
src <- DirSource(word.dir)
vc <- VCorpus(src)
vc <- tm_map(vc, removeWords, stopwords("english"))
dtm <- DocumentTermMatrix(vc)
dtm <- revise.dtm(dtm, del.voc, comb.voc)
docvoc <- dtm.to.docvoc(dtm,min.count=4)
docvoc <- rename.voc(docvoc, swap.voc)

doclist <- names(vc)
time <- t(sapply(doclist,parse.doc.name))[,4]

# Minor corrections for strange package behavior
dtm2 <- as.matrix(dtm)[,which(colSums(as.matrix(dtm))>4)]
cn.dtm2 <- colnames(dtm2)
dtm2 <- cbind( rep(0,nrow(dtm2)),dtm2)
colnames(dtm2) <- c('zzzzzzzzz',cn.dtm2)
