Replication package

FOMC transcripts were preprocessed using Python and analyzed using R.

Files
-------
analysis.R
base.R
ldamodels.R
speakerdifferences.R


