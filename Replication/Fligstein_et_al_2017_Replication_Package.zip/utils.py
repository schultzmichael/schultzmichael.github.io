def writeList(tlist, filename,encoding='utf-8'):
    outfile = open(filename,'w',encoding=encoding)
    for t in tlist:
        outfile.write(t+'\n')
    outfile.close()
def readList(filename,encoding='utf-8'):
    tlist = [t.replace("\n","") for t in open(filename,'r',encoding=encoding)]
    return tlist
def writeCSV(x, filename,delim=','):
    writeList([reduce(lambda x,y: x+delim+str(y),z,'') for z in x],filename)
def readCSV(filename,delim=','):
    return [x.split(delim) for x in readList(filename)]
def csvColumn(csvlist,col):
    return [x[col] for x in csvlist]
def readDict(filename):
    x = readCSV(filename)
    return {k:v for [k,v] in x}
    
