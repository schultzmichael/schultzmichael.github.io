Seeing Like the Fed: Culture, Cognition, and Framing and the Failure to Anticipate the Financial Crisis of 2008

Neil Fligstein and Jonah Stuart Brundage
Department of Sociology
University of California
Berkeley, CA 94720

Michael Schultz
Northwestern University
Evanston, IL 60208


Replication package
---------------------------
Direct any questions to michael.schultz@northwestern.edu

FOMC transcripts were preprocessed using Python and analyzed using R. Preprocessing is possible with included code, but not necessary for replication. Fitted models and processed transcripts are included.

Dependencies
--------------
Prepping Transcripts: 				RawText -> convert.py -> Transcripts / ProcessedTranscrpts
Fitting LDA: 						ProcessedTranscripts -> ldamodels.R
Analysing LDA:						FOMClda.RData -> analysis.R
'Topics by profession':				speakercodes.csv + Topic Scores/ -> speakerdifferences.R
Alternative analyses in appendices:	methodcomparison.R

Files
-------
RawText/				Unmodified text from FOMC transcripts - input into convert.py
Transcripts/			Modified text with speaker and previous speaker - input into projectQuotes.py
ProcessedTranscripts/	Modified text from FOMC transcripts - produced by convert.py - input into R
Topic Scores/			Scores determined by projecting transcripts into topic space - see projectQuotes.py

Data/					Miscellaneous codes and helper files			
Data/speakers.csv		Speaker codings
Data/speakercodes.csv	Same as speakers.csv with more description
Data/translation.csv 	Stem-Unstemmed word translation table
Data/topics.csv			Topic Word Weights - exported from R
Data/deletewords.txt	Words to be removed
Data/Rstopwords.txt		stop words used in R; used for consistency with R script
Data/swapwords.txt		words to replace
Data/transcripts.txt	List of transcript locations, used for downloading relevant transcripts

analysis.R				Code to analyze LDA output
ldamodels.R				Code for fitting LDA
speaker differences.R	Analyses used in section 'Topics by Profession'
methodcomparison.R		Analyses used in appendix
base.R					Code to load corpus and miscellaneous helper functions
setdirs.R				Set local directories here

convert.py				Code to convert text files into LDA input
projectQutoes.py		Project each transcript into topic vectors using topics.csv and transcripts/
Transcript.py			Helper functions for dealing with transcripts
utils.py				Random helper functions

alphavariations.RData	Models fit with different values of alpha
etavariations.RData		Models fit with different values of eta
FOMClda.RData			Model used in the paper