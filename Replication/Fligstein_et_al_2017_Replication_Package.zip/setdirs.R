# Change these directories
root.dir <- "./"
score.dir <- paste0(root.dir,'Topic Scores/')
data.dir <- paste0(root.dir,"Data/")
word.dir <- paste0(root.dir,"ProcessedTranscripts/")