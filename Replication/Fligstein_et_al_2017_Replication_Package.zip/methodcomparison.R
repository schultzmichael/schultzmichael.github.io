library(NMF)
source('base.R')

slt <- load.stem.leaf.table()

#################
# Non-negative matrix factorization
#################
x <- nmf(t(dtm2[,colSums(dtm2)>0]),15)

bx <- basis(x)
ptgw <- apply(bx,1,function(z) z/sum(z))
pwgt <- t(apply(bx,2,function(z) z/sum(z)))
wordtable <- sapply(1:ncol(bx), function(i) names(sort((pwgt*ptgw)[i,],decreasing=TRUE))[1:30])
for(i in 1:15)
	wordtable[,i] <- slt[wordtable[,i]]
print(wordtable)

k <- apply( cor(X$topic.proportions,t(coef(x))),2,which.max)
ordering <- order(apply(t(coef(x)),2,which.max))

par(mfrow=c(8,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in ordering[1:8]){
	y <- coef(x)[i,]/max(coef(x)[i,])
	if(i==ordering[8]){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) ,
			cex.axis=.75 )
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	polygon(c(time[1],time,time[length(time)]),c(0,y,0),col='white',border=NA)
	lines(time,y)
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,i,adj=c(.5,1),cex=1,font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}

par(mfrow=c(7,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in ordering[9:15]){
	y <- coef(x)[i,]/max(coef(x)[i,])
	if(i==ordering[15]){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ),
			cex.axis=.75 )
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	polygon(c(time[1],time,time[length(time)]),c(0,y,0),col='white',border=NA)
	lines(time,y)
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,i,adj=c(.5,1),cex=1,font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}



#################
# PCA
#################

x2 <- princomp(t(dtm2))

k <- apply( abs(cor(X$topic.proportions,x2$loadings)),2,which.max)
ordering <- order(apply(x2$loadings[,1:15],2,which.max))

par(mfrow=c(8,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in ordering[1:8]){
	y <- x2$loadings[,i]/max(abs(x2$loadings[,i]))
	s <- sign(cor(X$topic.proportions[,k[i]],x2$loadings[,i]))
	y <- y*s
	if(i==ordering[8]){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(-1,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) ,
			cex.axis=.75 )
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(-1,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	polygon(c(time[1],time,time[length(time)]),c(-1,y,-1),col='white',border=NA)
	lines(time,y)
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,i,adj=c(.5,1),font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}


par(mfrow=c(7,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in ordering[9:15]){
	y <- x2$loadings[,i]/max(abs(x2$loadings[,i]))
	s <- sign(cor(X$topic.proportions[,k[i]],x2$loadings[,i]))
	y <- y*s
	if(i==ordering[15]){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(-1,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) ,
			cex.axis=1)
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(-1,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	polygon(c(time[1],time,time[length(time)]),c(-1,y,-1),col='white',border=NA)
	lines(time,y)
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,i,adj=c(.5,1),font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}



bx <- x2$scores[,1:15]
ptgw <- apply(bx,1,function(z) z/sum(z))
pwgt <- t(apply(bx,2,function(z) z/sum(z)))
wordtable <- sapply(1:ncol(bx), function(i) names(sort((pwgt*ptgw)[i,],decreasing=TRUE))[1:30])
for(i in 1:15)
	wordtable[,i] <- slt[wordtable[,i]]
print(wordtable)

	
####################
# Word Count
####################
word.list <- c("subprim","bank","hous","inflat","price",
			"liquid","financi","minut","weak","growth",
			"energi","employ","portfolio","bubbl","respons")

x3 <- t(apply(dtm2[,word.list],1,function(z) z/sum(z)))

k <- apply( cor(X$topic.proportions,x3),2,which.max)

par(mfrow=c(8,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in 1:8){
  y <- x3[,i]/max(x3[,i])
  if(i==8){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) ,
			cex.axis=.75 )
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}
	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	
	polygon(c(time[1],time,time[length(time)]),c(0,y,0),col='white',border=NA)
	lines(time,dtm2[,word.list[i]]/max(dtm2[,word.list[i]]))
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,slt[word.list[i]],adj=c(.5,1),font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}

par(mfrow=c(7,1),mar=c(0,0,0,0),oma=c(3,1,1,1),family='serif',bg='white')
for(i in 9:15){
  y <- x3[,i]/max(x3[,i])
  if(i==15){
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) ,
			cex.axis=.75 )
	}else{
		plot(time,y,bty='l',
			type='n',xlab="",ylab="",ylim=c(0,1),yaxt='n',xaxt='n',
			xaxp=c(min(round(time)),max(round(time)),length(unique(round(time)))-1 ) )
	}
	
	for(t in unique(round(time)))
		abline(v=t,col='grey')
	
	polygon(c(time[1],time,time[length(time)]),c(0,y,0),col='white',border=NA)
	lines(time,dtm2[,word.list[i]]/max(dtm2[,word.list[i]]))
	lines(time,X$topic.proportions[,k[i]]/max(X$topic.proportions[,k[i]]),lty='dashed')
	text(mean(time),y=1,slt[word.list[i]],adj=c(.5,1),font=2)
	text(mean(time),y=1,topic.labels[k[i]],adj=c(.5,2.5),cex=.75)
}

