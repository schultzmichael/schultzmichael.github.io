import string
from stemming.porter2 import stem
from utils import *

#########################
### Speaker functions
#########################

speakerFixes = {"GREENPAN":"GREENSPAN","GREESPAN":"GREENSPAN","GRENSPAN":"GREENSPAN",
                "MOSCOW":"MOSKOW","KELLY":"KELLEY","ETLOW":"TETLOW",
                "GEITHER":"GEITHNER","ILCOX":"WILCOX","OHN":"KOHN",
                "RAMLICH":"GRAMLICH","TOCKTON":"STOCKTON"}

def findTitles(line):
    titles = ["MR.","MS.","MRS.","CHAIRMAN", "VICE CHAIRMAN","PRESIDENT","GOVERNOR"]
    for title in titles:
        k = line.find(title)
        if k>-1:
            break;
    return (k, len(title))
def extractSpeaker(line):
    (k,klen) = findTitles(line)
    if k>-1:
        k2 = line.find(".",k+klen)
        name = line[(k+klen+1):k2].strip()
        if name in speakerFixes:
            name = speakerFixes[name]
        if name==name.upper():
            return (name,k2+1)    
        
    return (None,None)

#########################
### Date functions             
#########################
monthDict = {"01":"January",
             "02":"February",
             "03":"March",
             "04":"April",
             "05":"May",
             "06":"June",
             "07":"July",
             "08":"August",
             "09":"September",
             "10":"October",
             "11":"November",
             "12":"December"}
def getDate(infile):
    k = infile.find("FOMC")
    year = infile[k+4:k+8]
    month = infile[k+8:k+10]
    day = infile[k+10:k+12]
    return (year,monthDict[month],str(int(day)))
def hasDateTag(line,date):
    mdlen = len(date[1]+" "+date[2])
    k = line.find(date[1]+" "+date[2])
    altk = line.find(date[1]+" "+str(int(date[2])-1))
    if k==-1 and altk != -1:
        k = altk
    k2 = line.find(date[0])
    if k>-1 and k2>-1:
        if k2-k<= mdlen+5:
            return(k, k2-k+4)
    return (-1,-1)

#########################
### Cleaning functions
#########################
def findWeirdCharacters(line,foundChars=""):
    return [c for c in line if c not in string.printable and c not in foundChars]

########################
### Text Prep Functions
########################
def getWords(text):
    return [w for w in text.split(" ") if len(w)>0]
def applyToWords(quote, transformFunc):
            newquote=""
            for word in quote.split(" "):
                newquote += " " + transformFunc(word)
            newquote.replace("  "," ")
            newquote.strip()
            return(newquote) 
def replaceList(x,l):
    for r in l:
        x = x.replace(r,' ')
    return x
    
def removePunc(x, puncList = [":",";",".",",","?","'",'"',"[","]",\
                              "-","_","!","`","~","<",">","/","*",\
                              "{","}","+","\f","\n","\t","\\","(",\
                              ")","\xe2","\x80","\x99","\x9d","$",\
                              "\x9c","\x94","\xbd","\x93","%","&"]):
    return replaceList(x,puncList)
def removeNumeric(x,numList=["1","2","3","4","5","6","7","8","9","0"]):
    return replaceList(x,numList)
def removeDropWords(x, dropList):
    return replaceList(x,dropList)
def replaceFromDict(x, replaceDict):
    if x in replaceDict:
        return replaceDict[x]
    return x
def stripQuotes(x):
    return x.strip()

def wordLength(text):
    return len(text.split(" "))


class Transcript:
    
    def __init__(self,filename=None,transcript=[]):
        self.filename=filename
        self.transcript=transcript        
        if self.filename is not None:
            self.parse(filename)        
        self.groups={}
        self.weights={}
        
    # Read    
    def parse(self, filename):
        self.filename=filename
        infile = filename
        
        transcript = []
        speaking = None
        precedingSpeaker=None
        quote=""
        i=0
        date=getDate(infile)
        for line in open(infile,'r',encoding='utf-8'):
            if line!="\n":
                i =i+1
                (k,klen) = hasDateTag(line, date)
                if k>-1:
                    k2 = line[k+klen:].find(" of ")
                    if k2>-1 and k2<10:
                        line=line[0:k]+line[(k+klen+8+k2):]
                    else:
                        line=line[0:k]+line[(k+klen):]
                if len(line)>0:
                    if line[-1]=="\n":
                        line = line[:-2]
                    (speaker,k) = extractSpeaker(line)
                    isNewSpeaker = speaker is not None
                    if(isNewSpeaker):
                        if speaking is not None:
                            transcript.append( (speaking,precedingSpeaker, quote.lower(), quote) )
                        precedingSpeaker=speaking
                        speaking = speaker
                        quote = line[k:].strip()
                    else:
                        quote += " " + line.strip()
        transcript.append( (speaking,precedingSpeaker,quote.lower(),quote) )

        self.transcript=transcript
        self.speakers = self.getSpeakers()

    # Write
    def read(self, infile):
        x = readList(infile)
        self.transcript = [line.split(',',3) for line in x]
        self.transcript = [(s.strip(), p.strip(), q.strip(),o) for [s,p,q,o] in self.transcript]
        self.speakers = self.getSpeakers()
        return self    
    def write(self, outfile):
        writeList([speaker+', '+str(preceding)+', '+quote+', '+original for (speaker,preceding,quote,original) in self.transcript],outfile)
    def writeQuotes(self, outfile):
        writeList([quote for (speaker,preceding,quote,original) in self.transcript],outfile)

    # Attributes
    def getSpeakers(self):
        s= list(set([speaker for (speaker,preceding,quote,original) in self.transcript]))
        s.sort()
        return s
    def numberOfSpeakers(self):
        return len(self.getSpeakers())
    def wordLength(self):
        return sum([wordLength(quote) for (speaker, preceding, quote,original) in self.transcript])
    def utteranceLength(self):
        return len(self.transcript)
    def countWords(self, wordcount={}):
        for quotewords in [quote.split(" ") for (speaker, preceding, quote,original) in self.transcript]:
            for word in quotewords:
                if word in wordcount:
                    wordcount[word] = wordcount[word]+1
                else:
                    wordcount[word] = 1
        return wordcount
    def useGrouping(self, groupDict):
        self.groups=groupDict
        return self
    def useWeights(self, weightDict):
        self.weights=weightDict
        return self

    # Editing functions
    def editQuotes(self,transformFunc,arg=None):
        if arg is None:
            self.transcript = [(speaker,preceding,transformFunc(quote),original) for (speaker,preceding,quote,original) in self.transcript]
        else:
            self.transcript = [(speaker,preceding,transformFunc(quote,arg),original) for (speaker,preceding,quote,original) in self.transcript]
        return self
    def editWords(self,transformFunc):
        self.transcript = [(speaker,preceding,applyToWords(quote,transformFunc),original) for (speaker,preceding,quote,original) in self.transcript]
        return self
    def replaceWords(self, replaceDict):
        return self.editWords(lambda w: replaceFromDict(w,replaceDict))
    def removeWords(self, removeList):
        return self.editWords(lambda w: "" if w in removeList else w)                                  
    def removeShortQuotes(self, length=2):
        self.transcript = [(speaker,preceding,quote,original) for(speaker,preceding,quote,original) in self.transcript if len(quote.split(" "))>length]
        return self
    def removeCharacters(self, charlist):
        self.transcript = [(speaker,preceding,replaceList(quote,charlist),original) for (speaker,preceding,quote,original) in self.transcript]
        return self


    # Cleaning
    def clean(self, weird, droplist=None,wordcount={}):
        self.editQuotes(removePunc)
        self.editQuotes(removeNumeric)
        self.removeCharacters(weird)
        wordcount = self.countWords(wordcount)
        self.editWords(stem)
        if not droplist is None:
            self.editQuotes(removeDropWords,droplist)
        self.editQuotes(stripQuotes)
        self.removeShortQuotes(2)
   
        return (self, wordcount)

    # Grouping functions
    def speakerGroup(self, spkr):
        if spkr is not None and spkr.lower() in self.groups:
            return self.groups[spkr.lower()]
        return 'X'
    def getGroups(self, includeOther=True):
        groups = list(set(self.groups.values()))
        if includeOther:
            groups.append('X')
        return groups

    # Scoring functions
    def scoreWord(self, word):
        if word in self.weights:
            return self.weights[word]
        return 0    
    def scoreUtterance(self, utterance):
        return sum([self.scoreWord(w) for w in getWords(utterance)])
    def scoreTranscript(self):
        return sum([self.scoreUtterance(quote) for (speaker,preceding,quote,original) in self.transcript])

    def normalizeByWordLength(self, x):
        wl = self.wordLength()
        if wl is not 0:
            return x / wl
        else:
            return float('inf')
    def normalizeByUtteranceLength(self, x):
        ul = self.utteranceLength()
        if ul is not 0:
            return x / ul
        else:
            return float('inf')
    def normalizeBySpeakerCount(self, x):
        n = self.numberOfSpeakers()
        if n is not 0:
            return x / n
        else:
            return float('inf')
    
    # Subset
    def subset(self, speaker=None,preceding=None,spkrSet=None,precSet=None,spkrGroup=None, precGroup=None):
        t = self.transcript
        if speaker is not None:
            t = [(s,p,q,o) for (s, p,q,o) in t if speaker==s]
        if preceding is not None:
            t = [(s,p,q,o) for (s, p,q,o) in t if preceding==p]
        if spkrSet is not None:
            t = [(s,p,q,o) for (s, p,q,o) in t if s in spkrSet]
        if precSet is not None:
            t = [(s,p,q,o) for (s,p,q,o) in t if p in precSet]
        if spkrGroup is not None:
            t = [(s,p,q,o) for (s,p,q,o) in t if self.speakerGroup(s) == spkrGroup]
        if precGroup is not None:
            t = [(s,p,q,o) for (s,p,q,o) in t if self.speakerGroup(str(p)) == precGroup]
        return Transcript(transcript=t).useWeights(self.weights).useGrouping(self.groups)
    
