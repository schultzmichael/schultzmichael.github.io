library(stringr)
source('base.R')

####################
# Helper functions
####################

read.scores <- function(infile){
  X <- read.table(infile,header=FALSE,sep = '\t')
  X[,-2]
}

average.topic.scores <- function(infile,min.length=0,normalize.by.length=FALSE,diff.from.prev=FALSE,
                                 permute=FALSE,  ...){
  scores <- read.scores(infile)
  scores <- scores[scores[,2]>=min.length,]
  if(permute)
    scores <- scores[sample.int(nrow(scores),replace=FALSE),]
  if(normalize.by.length){
    for(i in 3:ncol(scores))
      scores[,i] <- scores[,i]/scores[,2]
  }
  if(diff.from.prev)
    for(i in 3:ncol(scores))
      scores[2:nrow(scores),i] <- scores[2:nrow(scores),i] - scores[1:(nrow(scores)-1),i]
  sapply(1:(ncol(scores)-2),function(i)
    tapply(scores[,i+2],scores[,1],mean))
}

read.speaker.codes <- function(codefile=paste0(data.dir,'speakercodes.csv'))
  read.table(codefile,header=FALSE,sep=',',stringsAsFactors = FALSE)

compute.score.averages <- function(permute.speakers=FALSE, ...){
  score.files <- list.files(score.dir,full.names = TRUE)
  
  bankers <- read.speaker.codes()[,c(1,2)]
  rownames(bankers) <- toupper(bankers[,1])
  bankers <- bankers[,-1,drop=FALSE]
  
  if(permute.speakers){
    rn <- rownames(bankers)
    bankers <- bankers[sample.int(nrow(bankers),replace=FALSE),,drop=FALSE]
    rownames(bankers) <- rn
  }
  
  banker.names <- rownames(bankers)[bankers==1]
  nonbanker.names <- rownames(bankers)[bankers==0]
  
  banker <- list()
  nonbanker <- list()
  for (infile in score.files){
    #print(infile)
    mtg <- str_split(infile,'/')[[1]]
    mtg <- str_split(mtg[[length(mtg)]],fixed('.'))[[1]][1]
    avgs <- average.topic.scores(infile,...)
    if(length(banker.names%in%rownames(avgs))>0){
      banker[[infile]] <- colMeans(avgs[banker.names[banker.names%in%rownames(avgs)],,drop=FALSE])
    }else{
      banker[[infile]] <- rep(NA,ncol(avgs)-2)
    }
    if(length(nonbanker.names%in%rownames(avgs))>0){
      nonbanker[[infile]] <- colMeans(avgs[nonbanker.names[nonbanker.names%in%rownames(avgs)],,drop=FALSE])
    }else{
      nonbanker[[infile]] <- rep(NA,ncol(avgs)-2)
    }
  }
  list(simplify2array(banker),simplify2array(nonbanker))
}

############

topic.labels <- c("Bank Liquidity", "General", "Employment", "Weakness", "Financial Markets",
                  "Models", "Objectives", "Housing", "Inflation", "Portfolio",
                  "Productivity", "Energy", "Housing Bubble", "Policy Response", "Minutes")

# Compute score averages
z <- compute.score.averages(normalize.by.length=TRUE,diff.from.prev=FALSE,min.length=8) 

# Compute average differences
mn <- sapply(1:nrow(z[[1]]),function(i) mean(z[[1]][i,time<2008]-z[[2]][i,time<2008]) )
baseline <- sapply(1:nrow(z[[1]]),function(i) mean(z[[2]][i,time<2008]) )

# Bootstrap CIs
mn.star <- replicate(10000,{
  z <- compute.score.averages(normalize.by.length=TRUE,diff.from.prev=FALSE,min.length=8,
                              permute.speakers=TRUE) 
  sapply(1:nrow(z[[1]]),function(i) mean(z[[1]][i,time<2008]-z[[2]][i,time<2008]) )
})

# Build table
p <- round(sapply(1:length(mn),function(i) .5-abs(sum(mn[i]>mn.star[i,],na.rm=TRUE)/ncol(mn.star)-.5)),3)
z <- cbind('Estimate'=round(mn,4),
           'pval' = p,
           '95% CI lb' = round(apply(mn.star,1,quantile,0.025,na.rm=TRUE),4),
           '95% CI ub' = round(apply(mn.star,1,quantile,0.975,na.rm=TRUE),4),
           'Pct Diff'=paste0(format(round(mn/baseline*100,1),digits = 1),'%')
)
rownames(z) <-topic.labels
print(z)
