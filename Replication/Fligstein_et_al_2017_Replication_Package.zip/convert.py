
from utils import *
from Transcript import *


#########################
### Filename functions
#########################
def transcriptURL(partialURL):
    return("http://www.federalreserve.gov"+partialURL)
def transcriptFile(partialURL):
    return(partialURL[partialURL.find("FOMC"):])
def transcriptText(partialURL):
    filename = transcriptFile(partialURL)
    return filename[:filename.find(".pdf")]+".txt"
def processedFile(infile):
    return infile[4:infile.find("meeting")] + ".txt"
def transcriptDataFile(infile):
    return processedFile(infile).replace(".txt",".transcript")

#########################
### Low level Read / Write Functions
#########################
def readSets(setfile):
    setcsv = readCSV(setfile)
    names = csvColumn(setcsv,0)
    return [{n.lower():c for (n,c) in zip(names,csvColumn(setcsv,n+1))} for n in range(len(setcsv[0])-1)]    
def getCodeDict(n):
    return readSets('speakercodes.csv')[n-1]

#########################
### Set Functions
#########################
def splitByCode(transcript, n):
    codeDict = getCodeDict(n)
    codes = list(set(codeDict.values()))
    tDict = {}
    for code in codes:
        tDict[code] = subsetTranscriptBySet(transcript,code,codeDict)
    tDict['X'] = subsetTranscriptBySet(transcript,'X',codeDict)
    return tDict

def splitByCodes(transcript, n, c0, c1):
    return subsetTranscriptBySetOrder(transcript,c0,c1,getCodeDict(n))        





### Corpus functions

def findAllWeird():
    transcriptFiles = [transcriptText(partialURL) for partialURL in readList("transcripts.txt")]
    transcriptFiles = transcriptFiles[0:5]

    found = []
    for infile in transcriptFiles:
        transcript = Transcript(infile)
        for (speaker,preceding,quote,original) in transcript.transcript:
            found.extend(findWeirdCharacters(quote,found))
    return found

### Corpus Attributes

def getAllSpeakers(printEach=False):
    transcriptFiles = [transcriptText(partialURL) for partialURL in readList("transcripts.txt")]

    weird = findAllWeird()
    droplist = readList("droplist.txt")
    
    speakers={}
    wordcount={}
    for infile in transcriptFiles:
        transcript = Transcript(infile)
        speakers[infile] = transcript.getSpeakers()
        if printEach:
            print(speakers[infile])
    return speakers

def processCorpus():
    transcriptFiles = [transcriptText(partialURL) for partialURL in readList("transcripts.txt")]

    speakers = []
    for sl in getAllSpeakers().values():
        speakers = speakers + sl
    speakers = list(set(speakers))
    weird = findAllWeird()

    droplist = readList("droplist.txt")
    
    wordcount={}
    for infile in transcriptFiles:
        print(infile)
        outfile = processedFile(infile)
        
        (transcript, wordcount)  = Transcript(infile).clean(weird,droplist,wordcount)
           
        transcript.writeQuotes(outfile)
        transcript.write(transcriptDataFile(infile))

    stemDict={}
    for word in wordcount:
        stemword = stem(word)
        if stemword not in stemDict or wordcount[stemDict[stemword]]<wordcount[word]:
            stemDict[stemword] = word
        
    translation = [stemword+", "+stemDict[stemword] for stemword in stemDict]
    writeList(translation,"translation.csv")

def scoreQuotes(speaker, weights):
    transcriptFiles = [transcriptText(partialURL) for partialURL in readList("transcripts.txt")]
    
    scores = [] # file, score, quote
    for infile in transcriptFiles:
        infile = transcriptDataFile(infile)
        
        transcript = Transcript().read(infile)
        transcript = transcriptClean2(transcript)

        transcript.useWeights(weights)
        transcript = transcript.subset(speaker=speaker)
        scores = scores + [(infile, transcript.scoreUtterance(q)/wordLength(q), o) for (s,p,q,o) in transcript.transcript]
    return scores

def scoreCorpus():
    transcriptFiles = [transcriptText(partialURL) for partialURL in readList("transcripts.txt")]
    weightList = [getWeights(i) for i in range(1,16)]

    scores = [] # file, subsetA, subsetB, subsetC, topic, score
    counts = []# file, subsetA, subsetB, subsetC, type('u','w'), score
    for infile in transcriptFiles:
        infile = transcriptDataFile(infile)
        outfile = infile
        print(outfile)

        transcript = Transcript().read(infile)
        transcript = transcriptClean2(transcript)

        for i in range(len(weightList)):
           scores.append([infile, "NA","NA","NA", i+1,
                          transcript.normalizeByUtteranceLength(transcript.useWeights(weightList[i]).scoreTranscript())])
        counts.append([infile, "NA","NA","NA", 'w',
                       transcript.wordLength()])
        counts.append([infile, "NA","NA","NA", 'u',
                      transcript.utteranceLength()])

        for(n,name) in zip([1,2,3,4],['A','B','C','D']):
            transcript.useGrouping(getCodeDict(n))
            for c in transcript.getGroups():
                t = transcript.subset(spkrGroup=c)
                for i in range(len(weightList)):
                    scores.append([infile, name,c,"NA", i+1,
                                   t.normalizeByUtteranceLength(t.useWeights(weightList[i]).scoreTranscript())])
                    counts.append([infile, name,c,"NA", 'w',
                          t.wordLength()])
                    counts.append([infile, name,c,"NA", 'u',
                          t.utteranceLength()])

        for (n, name) in zip([1,2,3,4],['A','B','C','D']):
            transcript.useGrouping(getCodeDict(n))
            for c0 in transcript.getGroups():
                for c1 in transcript.getGroups():
                    t = transcript.subset(spkrGroup=c0,precGroup=c1)
                    for i in range(len(weightList)):
                        scores.append([infile, name,c0,c1, i+1,
                                       t.normalizeByUtteranceLength(t.useWeights(weightList[i]).scoreTranscript())])
                    counts.append([infile, name,c0,c1, 'w',
                                       t.wordLength()])
                    counts.append([infile, name,c0,c1, 'u',
                                       t.utteranceLength()])
        for speaker in transcript.getSpeakers():
            t = transcript.subset(speaker=speaker)
            for i in range(len(weightList)):
                scores.append([infile, speaker, "NA","NA", i+1,
                               t.normalizeByUtteranceLength(t.useWeights(weightList[i]).scoreTranscript())])
            counts.append([infile, speaker, "NA","NA", 'w',
                               t.wordLength()])
            counts.append([infile, speaker, "NA","NA", 'u',
                               t.utteranceLength()])
        
    writeCSV(scores,'scoresU.csv')
    writeCSV(counts,'counts.csv')
   
def readWeights():
    return readCSV('C:/Users/Michael/Dropbox/Fed Discussion/data/topics.csv')
    
def getWeights(n):
    x = readWeights()
    return {line[0].replace('"',''):float(line[n].replace('"','')) for line in x[1:]}


