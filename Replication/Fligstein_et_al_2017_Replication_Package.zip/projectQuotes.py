from utils import *
def readTranscript(infile,sep=',',encoding='utf-8'):
    x = readList(infile,encoding=encoding)#,encoding='ASCII')
    transcript = [line.split(sep,3) for line in x]
    transcript = [(s.strip(), p.strip(), q.strip(),o) for [s,p,q,o] in transcript]
    return transcript
def writeTranscript(transcript, outfile, sep=', '):
    writeList([speaker + sep + str(preceding)+ sep +quote+ sep + original for (speaker,preceding,quote,original) in transcript],outfile)

def readTopics(infile, sep='\t'):
    x = readList(infile)
    topics = [[w.replace('"','') for w in line.split(sep)] for line in x]
    words = topics[0]
    topics = topics[1:]
    topicDict = [{w:float(p) for (w,p) in zip(words,t)} for t in topics]
    return topicDict

def projectTranscript(infile, topicDict):
    print(infile)
    transcript = readTranscript(infile)
    out = []
    for line in transcript:
        [s,p,q,o] = line
        words = [w for w in q.split(' ') if len(w)>0]
        scores = [sum([topic[w] for w in words if w in topic]) for topic in topicDict]
        out.append([s,p,len(words)] + scores)
    return out

def scoreTranscripts(infilelist, topicfile, outfilelist):
    topics = readTopics(topicfile)
    for (infile,outfile) in zip(infilelist,outfilelist):
        scores = projectTranscript(infile, topics)
        writeTable(scores, outfile)

def transcriptDataFile(partialURL):
    root = partialURL[partialURL.find("FOMC"):]
    return root[4:root.find("meeting")] + ".transcript"    
def scoreFile(partialURL):
    filename = transcriptDataFile(partialURL)
    return filename[:filename.find(".transcript")]+".topicscore"

## Top level function
def runScores():
    transcriptFiles = ['Transcripts/'+transcriptDataFile(partialURL) for partialURL in readList("C:/Data/FedTranscripts/transcripts.txt")]
    scoreFiles = ['Topic Scores/'+scoreFile(partialURL) for partialURL in readList("C:/Data/FedTranscripts/transcripts.txt")]
    scoreTranscripts(transcriptFiles, '../Data/topics.tsv', scoreFiles)
