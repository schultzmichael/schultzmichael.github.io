source('base.R')

######
# Fit LDA to FOMC corpus
######
# The use of 'zzzzzzzzzz' is a quick fix to some strange behavior 
# in the lda package present at the time of running this model

K<-15 # Number of topics

lda0 <- lda.collapsed.gibbs.sampler(docvoc$doc, K, c(docvoc$voc,"zzzzzzzzz"), 2000, alpha=1/K,
                                    eta=.2, burnin = 400, compute.log.likelihood = TRUE)
colnames(lda0$topics) <- c("zzzzzzzzz",docvoc$voc)

assign(paste0("lda",K),lda0) # This is useful if you wish to look over a range of K

# Output should be saved if you want to use it with other scripts.

########################
# Vary the hyperparameters of alpha and eta
########################

alpha.list <- c(.01,.05,.1,.2,.4,.5,.75,1:4)
lda.list <- list()
K<-15
for(i in 1:length(alpha.list)){
	print(alpha.list[i])
	lda0 <- lda.collapsed.gibbs.sampler(docvoc$doc, K, 
		c(docvoc$voc,"zzzzzzzzz"), 2000, 
		alpha=alpha.list[i], eta=.2, 
		burnin = 400, compute.log.likelihood = TRUE)
	colnames(lda0$topics) <- c("zzzzzzzzz",docvoc$voc)
	lda.list[[i]] <- lda0
}
save(list="lda.list",file="alphavariations.RData")

K<-15
alpha <- 50/K
lda.list <- list()
eta.list <- c(.01, .05,.1,.2,.5,1)
for(i in 1:length(eta.list)){
	print(eta.list[i])
	lda0 <- lda.collapsed.gibbs.sampler(docvoc$doc, K, 
		c(docvoc$voc,"zzzzzzzzz"), 2000, 
		alpha=alpha, eta=eta.list[i], 
		burnin = 400, compute.log.likelihood = TRUE)
	colnames(lda0$topics) <- c("zzzzzzzzz",docvoc$voc)
	lda.list[[i]] <- lda0
}
save(list="lda.list",file="etavariations.RData")

##########
